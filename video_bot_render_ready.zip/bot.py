from pyrogram import Client, filters
import requests
import asyncio
from flask import Flask
import threading

API_ID = 26461305
API_HASH = "f35fa371be2aeb69005f4d038e6ff4ea"
BOT_TOKEN = "7031377504:AAG9mXaqFR9NCvhliIpoSwDGVGu0kIakb24"
GROUP_USERNAME = "Dark_Fsurf"
SAVEFROM_API = "https://worker.api-harshil.me/download?url="

app = Client("video_downloader_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

def is_supported_url(url):
    return any(domain in url for domain in ["tiktok.com", "facebook.com", "fb.watch", "instagram.com", "www.instagram.com", "vt.tiktok.com"])

async def is_member(client, user_id):
    try:
        member = await client.get_chat_member(GROUP_USERNAME, user_id)
        return member.status in ("member", "administrator", "creator")
    except:
        return False

@app.on_message(filters.command("start"))
async def start(client, message):
    user_id = message.from_user.id
    if not await is_member(client, user_id):
        await message.reply(
            f"🚫 Pour utiliser ce bot, tu dois d’abord rejoindre le groupe : [Dark_Fsurf](https://t.me/{GROUP_USERNAME})",
            disable_web_page_preview=True
        )
        return

    await message.reply("👋 Salut ! Envoie-moi un lien Facebook, Instagram ou TikTok et je t’enverrai la vidéo.")

@app.on_message(filters.text & ~filters.command("start"))
async def handle_link(client, message):
    user_id = message.from_user.id
    if not await is_member(client, user_id):
        await message.reply(
            f"❌ Tu dois rejoindre [@{GROUP_USERNAME}](https://t.me/{GROUP_USERNAME}) pour utiliser ce bot.",
            disable_web_page_preview=True
        )
        return

    url = message.text.strip()

    if not is_supported_url(url):
        await message.reply("⚠️ Lien non supporté. Merci d’envoyer un lien TikTok, Instagram ou Facebook.")
        return

    status = await message.reply("⏳ Téléchargement en cours...")

    try:
        response = requests.get(SAVEFROM_API + url)
        data = response.json()

        if "url" in data and data["url"]:
            video_url = data["url"]
            await status.edit("✅ Vidéo trouvée, envoi en cours...")
            await client.send_video(chat_id=message.chat.id, video=video_url, caption="🎬 Voici ta vidéo !")
        else:
            await status.edit("❌ Impossible de récupérer la vidéo. Essaie un autre lien.")
    except Exception as e:
        await status.edit("⚠️ Une erreur est survenue. Réessaie plus tard.")

def run_flask():
    flask_app = Flask('')
    
    @flask_app.route('/')
    def home():
        return "Bot is running!"

    flask_app.run(host='0.0.0.0', port=8080)

# Lancer le serveur Flask en arrière-plan
threading.Thread(target=run_flask).start()

app.run()